export default async function Home() {
  return <div>안녕</div>;
}
